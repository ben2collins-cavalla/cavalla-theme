jQuery.noConflict();
(function($){
	"use strict";
  var $first_slide = $('.carousel-item:nth-of-type(1)');
  $first_slide.parent().after($first_slide);

  $first_slide.addClass('active');

})(jQuery);
